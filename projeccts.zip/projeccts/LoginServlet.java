import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();

        if ("admin".equals(username) && "123".equals(password)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "admin");
            response.sendRedirect("AdminDashboardServlet");
        } else if ("user".equals(username) && "123".equals(password)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "user");
            response.sendRedirect("UserServlet");
        } else if ("daf".equals(username) && "123".equals(password)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "daf");
            response.sendRedirect("DafServlet");
        } else if ("csdm".equals(username) && "123".equals(password)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "csdm");
            response.sendRedirect("CsdmServlet");
        } else if ("supervisor".equals(username) && "123".equals(password)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "supervisor");
            response.sendRedirect("SupervisorServlet");
        } else if ("secretary".equals(username) && "123".equals(password)) {
            session.setAttribute("username", username);
            session.setAttribute("role", "secretary");
            response.sendRedirect("SecretaryServlet");
        } else {
            out.print("<script>alert('Invalid username or password.'); window.location.href='index.html';</script>");
        }
    }
}
