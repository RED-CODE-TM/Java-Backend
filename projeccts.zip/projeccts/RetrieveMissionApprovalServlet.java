import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RetrieveMissionApprovalServlet")
public class RetrieveMissionApprovalServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<MissionApproval> missionApprovalList = new ArrayList<>();
        
        String jdbcUrl = "jdbc:mysql://localhost:3306/mission__order";
        String jdbcUser = "root";
        String jdbcPassword = "root"; // Update with your MySQL root password

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            String sql = "SELECT * FROM mission_approval";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                MissionApproval missionApproval = new MissionApproval();
                missionApproval.setOrderId(resultSet.getString("order_id"));
                missionApproval.setApprovedBy(resultSet.getString("approved_by"));
                missionApproval.setApprovalStatus(resultSet.getString("approval_status"));
                missionApproval.setApprovalDate(resultSet.getDate("approval_date"));
                missionApproval.setComments(resultSet.getString("comments"));

                missionApprovalList.add(missionApproval);
            }

            request.setAttribute("missionApprovalList", missionApprovalList);
            resultSet.close();
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        request.getRequestDispatcher("displayMissionApproval.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
